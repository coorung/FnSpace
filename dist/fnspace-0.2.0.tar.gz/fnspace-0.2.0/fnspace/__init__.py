# -*- coding: utf-8 -*-
"""
Created on Thu Jun 27 09:42:12 2024

@author: coorung77
"""

from .core import FnSpace